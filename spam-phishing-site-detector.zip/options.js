/* Spam & Phishing Site Detector — options page logic.
 * Account (email + OTP login), Pro gating, scan history dashboard,
 * blocked-sites manager, trusted-sites manager. */

function el(id) { return document.getElementById(id); }

const CHIP_TEXT = {
  unconfigured: "Free",
  "logged-out": "Free",
  trial: "Trial",
  expired: "Trial over",
  pro: "Pro ✓",
};

// ------------------------------------------------------------------
// Account
// ------------------------------------------------------------------

async function renderAccount() {
  const state = await SPDLicense.getState();
  const chip = el("statusChip");
  chip.textContent =
    state.status === "trial" ? `Trial — ${state.daysLeft}d left` : CHIP_TEXT[state.status];

  el("acc-unconfigured").hidden = state.status !== "unconfigured";
  el("acc-logged-out").hidden = state.status !== "logged-out";
  el("acc-logged-in").hidden = !(state.status === "trial" || state.status === "expired" || state.status === "pro");

  el("trialDaysText").textContent = SPD_CONFIG.trialDays;

  if (state.email) el("accEmail").textContent = state.email;
  const msg = el("accountMsg");
  msg.classList.remove("ok");
  if (state.status === "pro") {
    msg.textContent = "Pro is active — thank you for supporting development! 💙";
    msg.classList.add("ok");
  } else if (state.status === "trial") {
    msg.textContent = `Your free Pro trial is active — ${state.daysLeft} day${state.daysLeft === 1 ? "" : "s"} left.`;
  } else if (state.status === "expired") {
    msg.textContent = "Your trial has ended. Unlock Pro to keep using these features.";
  } else {
    msg.textContent = "";
  }

  const upgrade = el("upgradeBox");
  upgrade.hidden = !(state.status === "trial" || state.status === "expired");
  el("priceLabel").textContent = SPD_CONFIG.priceLabel;
  const payBtn = el("payBtn");
  const payConfigured = /^https:\/\//.test(SPD_CONFIG.paymentUrl || "") && !String(SPD_CONFIG.paymentUrl).includes("PASTE_");
  if (payConfigured) {
    payBtn.href = SPD_CONFIG.paymentUrl;
    payBtn.textContent = "Pay & unlock";
  } else {
    payBtn.href = "#";
    payBtn.textContent = "Payments opening soon";
  }

  renderProGates(state);
  return state;
}

function renderProGates(state) {
  const unlocked = SPDLicense.isUnlocked(state);
  for (const id of ["historyCard", "blockCard"]) {
    const card = el(id);
    card.classList.toggle("locked", !unlocked);
    card.querySelector(".lock").hidden = unlocked;
  }
  const lockMsg =
    state.status === "expired"
      ? `Trial over — pay once (${SPD_CONFIG.priceLabel}), keep Pro for life`
      : state.status === "unconfigured"
        ? "Pro features are coming soon"
        : `Log in above to try Pro free for ${SPD_CONFIG.trialDays} days`;
  el("historyLockMsg").textContent = lockMsg;
  el("blockLockMsg").textContent = lockMsg;
}

function wireAccount() {
  const loginMsg = el("loginMsg");

  el("sendCodeBtn").addEventListener("click", async () => {
    const email = el("emailInput").value.trim();
    loginMsg.classList.remove("ok");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
      loginMsg.textContent = "Enter a valid email address";
      return;
    }
    const btn = el("sendCodeBtn");
    btn.disabled = true;
    try {
      await SPDLicense.requestOtp(email);
      el("otpRow").hidden = false;
      loginMsg.textContent = "Code sent! Check your inbox (and spam folder).";
      loginMsg.classList.add("ok");
      el("otpInput").focus();
    } catch (err) {
      loginMsg.textContent = err.message;
    } finally {
      btn.disabled = false;
    }
  });

  el("verifyBtn").addEventListener("click", async () => {
    const btn = el("verifyBtn");
    btn.disabled = true;
    loginMsg.classList.remove("ok");
    try {
      await SPDLicense.verifyOtp(el("emailInput").value, el("otpInput").value);
      loginMsg.textContent = "";
      await renderAccount();
    } catch (err) {
      loginMsg.textContent = err.message;
    } finally {
      btn.disabled = false;
    }
  });

  el("refreshBtn").addEventListener("click", async () => {
    const btn = el("refreshBtn");
    btn.disabled = true;
    try {
      await SPDLicense.refresh(true);
      await renderAccount();
    } finally {
      btn.disabled = false;
    }
  });

  el("logoutBtn").addEventListener("click", async () => {
    await SPDLicense.logout();
    el("otpRow").hidden = true;
    await renderAccount();
  });
}

// ------------------------------------------------------------------
// Scan history (Pro)
// ------------------------------------------------------------------

function timeAgo(t) {
  const m = Math.floor((Date.now() - t) / 60000);
  if (m < 1) return "now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

async function renderHistory() {
  const { history = [] } = await chrome.storage.local.get("history");
  const week = history.filter((e) => Date.now() - e.t < 7 * 86400000);
  const flagged = week.filter((e) => e.v === "red" || e.v === "amber").length;
  el("historySummary").textContent = week.length
    ? `Last 7 days: ${week.length} sites checked, ${flagged} flagged as risky.`
    : "Nothing recorded yet — browse a little and come back.";

  const list = el("historyList");
  list.textContent = "";
  for (const entry of history.slice(0, 50)) {
    const row = document.createElement("div");
    row.className = "item";
    const dot = document.createElement("span");
    dot.className = `vdot ${entry.v}`;
    const domain = document.createElement("span");
    domain.className = "domain";
    domain.textContent = entry.d;
    const when = document.createElement("span");
    when.className = "when";
    when.textContent = timeAgo(entry.t);
    row.append(dot, domain, when);
    list.append(row);
  }
  if (!history.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "No history yet.";
    list.append(empty);
  }
}

// ------------------------------------------------------------------
// Blocked & trusted site lists
// ------------------------------------------------------------------

function domainListRow(domain, onRemove) {
  const row = document.createElement("div");
  row.className = "item";
  const name = document.createElement("span");
  name.className = "domain";
  name.textContent = domain;
  const btn = document.createElement("button");
  btn.textContent = "Remove";
  btn.addEventListener("click", onRemove);
  row.append(name, btn);
  return row;
}

async function renderLists() {
  const { userBlocklist = [], userAllowlist = [] } = await chrome.storage.sync.get([
    "userBlocklist",
    "userAllowlist",
  ]);

  const blockList = el("blockList");
  blockList.textContent = "";
  for (const d of userBlocklist) {
    blockList.append(
      domainListRow(d, async () => {
        await chrome.storage.sync.set({ userBlocklist: userBlocklist.filter((x) => x !== d) });
        renderLists();
      })
    );
  }
  if (!userBlocklist.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "No blocked sites yet.";
    blockList.append(empty);
  }

  const trustList = el("trustList");
  trustList.textContent = "";
  for (const d of userAllowlist) {
    trustList.append(
      domainListRow(d, async () => {
        await chrome.storage.sync.set({ userAllowlist: userAllowlist.filter((x) => x !== d) });
        renderLists();
      })
    );
  }
  if (!userAllowlist.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "No trusted sites yet — use “Trust this site” in the popup.";
    trustList.append(empty);
  }
}

function wireLists() {
  el("blockAddBtn").addEventListener("click", async () => {
    const raw = el("blockInput").value.trim().toLowerCase();
    const msg = el("blockMsg");
    msg.classList.remove("ok");
    if (!raw) return;
    // Accept either a bare domain or a full URL.
    let host = raw.replace(/^https?:\/\//, "").split("/")[0];
    const domain = SiteSafety.getRegisteredDomain(host);
    if (!domain || !domain.includes(".")) {
      msg.textContent = "Enter a valid domain, like example.com";
      return;
    }
    const { userBlocklist = [] } = await chrome.storage.sync.get("userBlocklist");
    if (userBlocklist.includes(domain)) {
      msg.textContent = `${domain} is already blocked`;
      return;
    }
    await chrome.storage.sync.set({ userBlocklist: [...userBlocklist, domain] });
    el("blockInput").value = "";
    msg.textContent = `Blocked ${domain}`;
    msg.classList.add("ok");
    renderLists();
  });

  el("clearHistoryBtn").addEventListener("click", async () => {
    await chrome.storage.local.remove("history");
    renderHistory();
  });
}

// ------------------------------------------------------------------

(async function init() {
  // ?compact=1 → MetaMask-style popup window; ⛶ opens the full page.
  if (new URLSearchParams(location.search).get("compact")) {
    document.documentElement.classList.add("compact");
  }
  el("expandBtn").addEventListener("click", (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: chrome.runtime.getURL("options.html") });
    window.close();
  });

  wireAccount();
  wireLists();
  await renderAccount();
  await renderHistory();
  await renderLists();
  // Pick up purchases / trial changes recorded server-side.
  const state = await SPDLicense.refresh(false);
  renderProGates(state);
})();
