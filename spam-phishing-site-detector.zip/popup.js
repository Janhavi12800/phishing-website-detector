/* Spam & Phishing Site Detector — popup. Shows the verdict for the active tab with an
 * animated risk gauge and the full list of reasons, and lets the user
 * trust/untrust the current site. */

const UI = {
  green: { label: "Looks safe", heading: "Assessment" },
  amber: { label: "Be careful", heading: "Warning signs" },
  red: { label: "Likely phishing or scam", heading: "Warning signs" },
  gray: { label: "Not rated", heading: "" },
};

const GAUGE_CIRC = 2 * Math.PI * 25;

function el(id) { return document.getElementById(id); }

function send(msg) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage(msg, (r) => {
        resolve(chrome.runtime.lastError ? null : r);
      });
    } catch {
      resolve(null);
    }
  });
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function setGauge(verdict, result) {
  const bar = el("gaugeBar");
  const num = el("gaugeNum");
  bar.style.strokeDasharray = String(GAUGE_CIRC);
  bar.style.strokeDashoffset = String(GAUGE_CIRC);
  let frac = 0;
  let text = "–";
  if (verdict === "green") {
    frac = 1; // full ring reads as "all clear"
    text = "✓";
  } else if (verdict === "amber" || verdict === "red") {
    frac = Math.min(result.score || 0, 100) / 100;
    text = String(result.score || 0);
  }
  num.textContent = text;
  // Double rAF so the initial offset paints first and the ring animates in.
  requestAnimationFrame(() => requestAnimationFrame(() => {
    bar.style.strokeDashoffset = String(GAUGE_CIRC * (1 - frac));
  }));
}

function render(result, tab) {
  const verdict = result ? (result.special ? "gray" : result.verdict) : "gray";
  el("header").className = verdict;
  for (const g of document.querySelectorAll(".glyph")) g.hidden = true;
  const glyph = el("g-" + verdict);
  if (glyph) glyph.hidden = false;
  el("label").textContent = UI[verdict].label;
  el("domain").textContent = result && result.registeredDomain
    ? result.registeredDomain
    : (tab && tab.url ? tab.url.slice(0, 80) : "");
  setGauge(verdict, result || { score: 0 });

  const content = el("content");
  content.textContent = "";
  if (result && result.reasons && result.reasons.length) {
    if (UI[verdict].heading) {
      const h = document.createElement("h2");
      h.textContent = UI[verdict].heading;
      content.append(h);
    }
    const icon = result.trusted ? "✓" : verdict === "gray" ? "ℹ" : "⚠";
    result.reasons.forEach((r, i) => {
      const row = document.createElement("div");
      row.className = "reason";
      row.style.animationDelay = `${Math.min(i, 8) * 70}ms`;
      const ico = document.createElement("span");
      ico.className = "ico";
      ico.textContent = icon;
      const txt = document.createElement("span");
      txt.textContent = r;
      row.append(ico, txt);
      content.append(row);
    });
    if (!result.special && !result.trusted) {
      const s = document.createElement("div");
      s.className = "scoreline";
      s.textContent = `Risk score ${result.score} — amber from ${SiteSafety.THRESHOLDS.amber}, red from ${SiteSafety.THRESHOLDS.red}`;
      content.append(s);
    }
  } else {
    const p = document.createElement("div");
    p.className = "scoreline";
    p.textContent = "This page can't be rated (browser pages, the web store, and local files are excluded).";
    content.append(p);
  }
}

async function renderActions(result, tab) {
  const actions = el("actions");
  actions.textContent = "";
  if (!result || result.special || !result.registeredDomain) return;
  if (result.trusted === "allowlist") return; // built-in trust, nothing to toggle

  const { userAllowlist = [] } = await chrome.storage.sync.get("userAllowlist");
  const domain = result.registeredDomain;
  const trusted = userAllowlist.includes(domain);

  const btn = document.createElement("button");
  // On a red verdict the trust action is deliberately understated — a
  // prominent button on a likely-phishing page invites mistakes.
  btn.className = trusted || result.verdict === "red" ? "trust secondary" : "trust";
  btn.textContent = trusted ? `Stop trusting ${domain}` : `Trust ${domain}`;
  btn.addEventListener("click", async () => {
    const next = trusted ? userAllowlist.filter((d) => d !== domain) : [...userAllowlist, domain];
    await chrome.storage.sync.set({ userAllowlist: next });
    const fresh = await send({ type: "rescore", tabId: tab.id });
    render(fresh, tab);
    renderActions(fresh, tab);
  });
  actions.append(btn);
}

(async function init() {
  const tab = await getActiveTab();
  if (!tab) return;
  let result = await send({ type: "get-verdict", tabId: tab.id });
  if (!result && tab.url) {
    result = await send({ type: "rescore", tabId: tab.id });
  }
  render(result, tab);
  renderActions(result, tab);
})();
