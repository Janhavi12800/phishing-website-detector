/* Spam & Phishing Site Detector — content script.
 * Collects page signals, sends them to the service worker, and shows a
 * warning banner for amber/red verdicts. Runs in the top frame only.
 *
 * Trust model: the page being warned about is attacker-controlled and CAN
 * remove or cover this banner (it lives in the shared DOM; the closed
 * shadow root only protects its internals). A watchdog re-attaches it, but
 * the authoritative indicator is the toolbar icon + badge, which pages
 * cannot touch. Deliberately NO in-page "looks safe" indicator: a positive
 * signal rendered in page-controllable space is spoofable by construction. */

(function () {
  "use strict";
  if (window.top !== window) return;

  const pageRegistered = SiteSafety.getRegisteredDomain(location.hostname);

  function collectSignals() {
    const signals = {
      https: location.protocol === "https:",
      passwordFields: document.querySelectorAll('input[type="password"]').length,
      crossOriginForms: 0,
      linkMismatches: 0,
      hiddenIframes: 0,
      metaRefreshCrossDomain: false,
      title: (document.title || "").slice(0, 300),
    };

    for (const form of document.forms) {
      try {
        // .action resolves relative URLs; an empty action means "this page".
        const action = form.getAttribute("action");
        if (!action) continue;
        const target = new URL(form.action, location.href);
        if (!/^https?:$/.test(target.protocol)) continue;
        if (SiteSafety.getRegisteredDomain(target.hostname) !== pageRegistered) {
          signals.crossOriginForms++;
        }
      } catch { /* unparsable action */ }
    }

    const domainInText = /([a-z0-9][a-z0-9-]{1,62}\.)+[a-z]{2,12}/i;
    const anchors = document.querySelectorAll("a[href]");
    let checked = 0;
    for (const a of anchors) {
      if (checked >= 200) break;
      const text = (a.textContent || "").trim().toLowerCase();
      if (text.length < 4 || text.length > 120) continue;
      const m = text.match(domainInText);
      if (!m) continue;
      checked++;
      try {
        const href = new URL(a.href, location.href);
        if (!/^https?:$/.test(href.protocol)) continue;
        const shown = SiteSafety.getRegisteredDomain(m[0]);
        const actual = SiteSafety.getRegisteredDomain(href.hostname);
        if (shown !== actual) signals.linkMismatches++;
      } catch { /* ignore */ }
    }

    for (const frame of document.querySelectorAll("iframe[src]")) {
      try {
        const src = new URL(frame.src, location.href);
        if (!/^https?:$/.test(src.protocol)) continue;
        if (SiteSafety.getRegisteredDomain(src.hostname) === pageRegistered) continue;
        const style = getComputedStyle(frame);
        const hidden =
          style.display === "none" ||
          style.visibility === "hidden" ||
          frame.offsetWidth <= 2 ||
          frame.offsetHeight <= 2;
        if (hidden) signals.hiddenIframes++;
      } catch { /* ignore */ }
    }

    const meta = document.querySelector('meta[http-equiv="refresh" i]');
    if (meta) {
      const m = /url\s*=\s*(.+)$/i.exec(meta.content || "");
      if (m) {
        try {
          const dest = new URL(m[1].trim().replace(/^['"]|['"]$/g, ""), location.href);
          if (SiteSafety.getRegisteredDomain(dest.hostname) !== pageRegistered) {
            signals.metaRefreshCrossDomain = true;
          }
        } catch { /* ignore */ }
      }
    }

    return signals;
  }

  // ---------------------------------------------------------------
  // Warning banner (amber/red only)
  // ---------------------------------------------------------------

  const PALETTE = {
    amber: {
      bg: "linear-gradient(135deg, #92400e, #d97706)",
      label: "Be careful",
    },
    red: {
      bg: "linear-gradient(135deg, #991b1b, #dc2626)",
      label: "Warning: this site looks dangerous",
    },
  };

  // Static markup only — never page data — so innerHTML is safe here.
  const SHIELD_SVG =
    '<svg viewBox="0 0 100 100" width="24" height="24" aria-hidden="true">' +
    '<path d="M50 5 L89 17 L89 52 Q89 80 50 97 Q11 80 11 52 Z" fill="none" stroke="#fff" stroke-width="7" stroke-linejoin="round"/>' +
    '<path d="M50 28 L50 54" stroke="#fff" stroke-width="9" stroke-linecap="round"/>' +
    '<circle cx="50" cy="68" r="5.5" fill="#fff"/></svg>';

  function assertHostVisible(host) {
    // Inline !important beats page-stylesheet !important rules targeting
    // the host element.
    host.style.setProperty("display", "block", "important");
    host.style.setProperty("visibility", "visible", "important");
    host.style.setProperty("opacity", "1", "important");
  }

  // Re-attach the banner if the page deletes it. Capped so a page fighting
  // back can't trap us in an infinite battle — the toolbar badge remains.
  // The observer watches only the host's parent (cheap); the interval is a
  // backstop for wholesale body replacement, which the observer can't see.
  function startWatchdog(host, state) {
    const teardown = () => {
      if (state.observer) state.observer.disconnect();
      if (state.timer) clearInterval(state.timer);
    };
    state.teardown = teardown;
    const arm = () => {
      state.observer.disconnect();
      if (host.parentNode) state.observer.observe(host.parentNode, { childList: true });
    };
    const reattach = () => {
      if (state.dismissed) return;
      if (state.reattaches >= 25) { teardown(); return; }
      if (!host.isConnected) {
        state.reattaches++;
        (document.body || document.documentElement).append(host);
        assertHostVisible(host);
        arm();
      } else if (host.style.getPropertyValue("display") !== "block") {
        assertHostVisible(host); // only write CSSOM when something changed
      }
    };
    state.observer = new MutationObserver(reattach);
    arm();
    state.timer = setInterval(reattach, 2000);
  }

  function showWarningBanner(result) {
    if (!result || result.special) return;
    const p = PALETTE[result.verdict];
    if (!p) return; // green/gray: toolbar icon only

    const host = document.createElement("div");
    const state = { dismissed: false, reattaches: 0, observer: null, timer: null };
    const shadow = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = `
      :host { all: initial; }
      .banner {
        position: fixed; top: 0; left: 0; right: 0; z-index: 2147483647;
        background: ${p.bg}; color: #fff;
        font: 14px/1.5 system-ui, -apple-system, "Segoe UI", sans-serif;
        padding: 12px 20px; box-shadow: 0 6px 24px rgba(0,0,0,.35);
        transform: translateY(-110%);
        transition: transform .5s cubic-bezier(.2,.9,.25,1);
      }
      .banner.show { transform: translateY(0); }
      .row { display: flex; align-items: center; gap: 12px; max-width: 1100px; margin: 0 auto; }
      .icon { width: 24px; height: 24px; flex: none; display: flex; }
      .msg { flex: 1; font-weight: 600; text-shadow: 0 1px 2px rgba(0,0,0,.2); }
      button {
        font: 600 13px system-ui, sans-serif; cursor: pointer;
        border: 1px solid rgba(255,255,255,.45); border-radius: 8px;
        background: rgba(255,255,255,.14); color: #fff; padding: 6px 14px;
        transition: background .15s ease, transform .1s ease;
      }
      button:hover { background: rgba(255,255,255,.28); }
      button:active { transform: scale(.96); }
      ul { margin: 10px 0 2px; padding-left: 36px; max-width: 1100px;
           margin-left: auto; margin-right: auto; display: none; }
      ul.open { display: block; }
      li { margin: 4px 0; font-weight: 400; font-size: 13px; opacity: .95; }
    `;
    shadow.append(style);

    const banner = document.createElement("div");
    banner.className = "banner";
    const row = document.createElement("div");
    row.className = "row";
    const icon = document.createElement("span");
    icon.className = "icon";
    icon.innerHTML = SHIELD_SVG;
    const msg = document.createElement("span");
    msg.className = "msg";
    msg.textContent =
      result.verdict === "red"
        ? `${p.label} — do not enter passwords or payment details here.`
        : `${p.label} — this site has some warning signs.`;
    const details = document.createElement("button");
    details.textContent = "Why?";
    const dismiss = document.createElement("button");
    dismiss.textContent = "Dismiss";
    row.append(icon, msg, details, dismiss);

    const list = document.createElement("ul");
    for (const r of result.reasons.slice(0, 8)) {
      const li = document.createElement("li");
      li.textContent = r; // textContent only — never inject page data as HTML
      list.append(li);
    }
    details.addEventListener("click", () => list.classList.toggle("open"));
    dismiss.addEventListener("click", () => {
      state.dismissed = true;
      if (state.teardown) state.teardown();
      host.remove();
    });
    banner.append(row, list);
    shadow.append(banner);

    (document.body || document.documentElement).append(host);
    assertHostVisible(host);
    startWatchdog(host, state);
    requestAnimationFrame(() => banner.classList.add("show"));
  }

  function run() {
    let signals;
    try {
      signals = collectSignals();
    } catch {
      signals = null;
    }
    try {
      chrome.runtime.sendMessage({ type: "content-signals", signals }, (result) => {
        if (chrome.runtime.lastError) return; // worker unavailable; icon still set
        showWarningBanner(result);
      });
    } catch { /* extension was reloaded; ignore */ }
  }

  if (document.readyState === "complete" || document.readyState === "interactive") {
    run();
  } else {
    document.addEventListener("DOMContentLoaded", run, { once: true });
  }
})();
