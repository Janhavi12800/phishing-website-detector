/* Spam & Phishing Site Detector — MV3 service worker.
 * Scores every navigation, stores the result per tab, and colors the
 * toolbar icon green / amber / red / gray. */

importScripts("lib/scoring.js");

const COLORS = {
  green: "#1e8e3e",
  amber: "#f0a000",
  red: "#d93025",
  gray: "#9aa0a6",
};

const LABELS = {
  green: "Looks safe",
  amber: "Be careful — some warning signs",
  red: "Danger — likely phishing or scam",
  gray: "Not rated",
};

const tabKey = (tabId) => `tab:${tabId}`;

async function getUserLists() {
  const { userAllowlist = [], userBlocklist = [] } = await chrome.storage.sync.get([
    "userAllowlist",
    "userBlocklist",
  ]);
  return { userAllowlist, userBlocklist };
}

// Scan history for the options-page dashboard (newest first, capped).
const HISTORY_MAX = 500;
async function recordHistory(result) {
  if (!result || result.special || !result.registeredDomain) return;
  const { history = [] } = await chrome.storage.local.get("history");
  const top = history[0];
  if (top && top.u === result.url && top.v === result.verdict) return; // reloads
  history.unshift({
    t: Date.now(),
    d: result.registeredDomain,
    u: result.url,
    v: result.verdict,
    s: result.score,
  });
  await chrome.storage.local.set({ history: history.slice(0, HISTORY_MAX) });
}

// Verdict gradients for the dynamic shield icon (light top -> dark bottom).
const GRADIENTS = {
  green: ["#34d399", "#047857"],
  amber: ["#fbbf24", "#b45309"],
  red: ["#f87171", "#b91c1c"],
  gray: ["#9ca3af", "#4b5563"],
};

function shieldPath(ctx, s) {
  ctx.beginPath();
  ctx.moveTo(s * 0.5, s * 0.05);
  ctx.lineTo(s * 0.89, s * 0.17);
  ctx.lineTo(s * 0.89, s * 0.52);
  ctx.quadraticCurveTo(s * 0.89, s * 0.80, s * 0.5, s * 0.97);
  ctx.quadraticCurveTo(s * 0.11, s * 0.80, s * 0.11, s * 0.52);
  ctx.lineTo(s * 0.11, s * 0.17);
  ctx.closePath();
}

// Draw a gradient shield in the verdict color, with a glyph so the states
// are distinguishable without color alone (✓ / ! / ✕ / –).
function drawIcon(verdict, size) {
  const [top, bottom] = GRADIENTS[verdict] || GRADIENTS.gray;
  const c = new OffscreenCanvas(size, size);
  const ctx = c.getContext("2d");
  const grad = ctx.createLinearGradient(0, 0, 0, size);
  grad.addColorStop(0, top);
  grad.addColorStop(1, bottom);
  shieldPath(ctx, size);
  ctx.fillStyle = grad;
  ctx.fill();

  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = Math.max(1.8, size * 0.11);
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.beginPath();
  if (verdict === "green") {
    ctx.moveTo(size * 0.32, size * 0.47);
    ctx.lineTo(size * 0.45, size * 0.60);
    ctx.lineTo(size * 0.69, size * 0.33);
  } else if (verdict === "red") {
    ctx.moveTo(size * 0.36, size * 0.31);
    ctx.lineTo(size * 0.64, size * 0.59);
    ctx.moveTo(size * 0.64, size * 0.31);
    ctx.lineTo(size * 0.36, size * 0.59);
  } else if (verdict === "amber") {
    ctx.moveTo(size * 0.5, size * 0.26);
    ctx.lineTo(size * 0.5, size * 0.48);
  } else {
    ctx.moveTo(size * 0.36, size * 0.44);
    ctx.lineTo(size * 0.64, size * 0.44);
  }
  ctx.stroke();
  if (verdict === "amber") {
    ctx.beginPath();
    ctx.arc(size * 0.5, size * 0.62, Math.max(1.2, size * 0.065), 0, Math.PI * 2);
    ctx.fillStyle = "#ffffff";
    ctx.fill();
  }
  return ctx.getImageData(0, 0, size, size);
}

async function setIndicator(tabId, result) {
  const verdict = result ? (result.special ? "gray" : result.verdict) : "gray";
  try {
    await chrome.action.setIcon({
      tabId,
      imageData: { 16: drawIcon(verdict, 16), 32: drawIcon(verdict, 32) },
    });
    const detail = result && result.reasons.length ? ` — ${result.reasons[0]}` : "";
    await chrome.action.setTitle({ tabId, title: `Spam & Phishing Detector: ${LABELS[verdict]}${detail}` });
    // The badge is the tamper-proof warning channel: hostile pages can fight
    // the in-page banner, but nothing in a page can touch the toolbar.
    const warning = verdict === "red" || verdict === "amber";
    await chrome.action.setBadgeText({ tabId, text: warning ? "!" : "" });
    if (warning) {
      await chrome.action.setBadgeBackgroundColor({ tabId, color: COLORS[verdict] });
      // Chrome 110+ only; older Chrome auto-picks a contrasting text color.
      if (chrome.action.setBadgeTextColor) {
        await chrome.action.setBadgeTextColor({ tabId, color: "#ffffff" });
      }
    }
  } catch {
    // Tab may have closed between scoring and painting; nothing to do.
  }
}

async function scoreTab(tabId, url) {
  const { userAllowlist, userBlocklist } = await getUserLists();
  const key = tabKey(tabId);
  const prev = (await chrome.storage.session.get(key))[key];
  const result = SiteSafety.analyzeUrl(url, userAllowlist, userBlocklist);
  await chrome.storage.session.set({ [key]: result });
  await setIndicator(tabId, result);
  if (!prev || prev.url !== url) recordHistory(result);
  return result;
}

// Re-score every open tab when the user's trust/block lists change, so a
// newly blocked or trusted site takes effect immediately — no refresh needed.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "sync") return;
  if (!changes.userBlocklist && !changes.userAllowlist) return;
  (async () => {
    const tabs = await chrome.tabs.query({ url: ["http://*/*", "https://*/*"] });
    for (const tab of tabs) {
      if (tab.id != null && tab.url) await scoreTab(tab.id, tab.url);
    }
  })();
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Score when a navigation starts and whenever the committed URL changes
  // (redirects and SPA navigations fire onUpdated with changeInfo.url).
  if ((changeInfo.status === "loading" || changeInfo.url) && tab.url) {
    scoreTab(tabId, tab.url);
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.session.remove(tabKey(tabId));
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg && msg.type === "content-signals" && sender.tab && sender.tab.id != null) {
      const key = tabKey(sender.tab.id);
      const stored = await chrome.storage.session.get(key);
      let urlResult = stored[key];
      if (!urlResult || urlResult.url !== sender.tab.url) {
        const { userAllowlist, userBlocklist } = await getUserLists();
        urlResult = SiteSafety.analyzeUrl(sender.tab.url || sender.url, userAllowlist, userBlocklist);
      }
      const merged = SiteSafety.combine(urlResult, msg.signals);
      await chrome.storage.session.set({ [key]: merged });
      await setIndicator(sender.tab.id, merged);
      if (merged.verdict !== urlResult.verdict) recordHistory(merged);
      sendResponse(merged);
    // get-verdict/rescore are popup-only: extension pages have no sender.tab,
    // content scripts always do — keeps a compromised-page context from
    // reading other tabs' URLs/verdicts.
    } else if (msg && msg.type === "get-verdict" && !sender.tab && typeof msg.tabId === "number") {
      const stored = await chrome.storage.session.get(tabKey(msg.tabId));
      sendResponse(stored[tabKey(msg.tabId)] || null);
    } else if (msg && msg.type === "rescore" && !sender.tab && typeof msg.tabId === "number") {
      try {
        const tab = await chrome.tabs.get(msg.tabId);
        sendResponse(tab.url ? await scoreTab(msg.tabId, tab.url) : null);
      } catch {
        sendResponse(null);
      }
    } else {
      sendResponse(null);
    }
  })();
  return true; // keep the message channel open for the async response
});
